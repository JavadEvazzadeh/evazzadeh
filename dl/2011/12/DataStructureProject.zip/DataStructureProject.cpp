/*****************************************************************************/
/*                        Data Structure Project v1.0                        */
/*          This simple program managing information by linked list.         */
/*         in this program you can add, delete and show student data.        */
/*                                                                           */
/*   Programming by                                                          */
/*                  Javad Evazzadeh Kakroudi     870382401                   */
/*****************************************************************************/

#include <cstdlib>
#include <iostream>
#include <conio.h>
#include <cstring>
#include <iomanip>

using namespace std;
int menu();                                      // show user interface menu
int tmp;                                         // temp variable!
/*** -------------   declaration student linked list class   ------------- ***/
class slinkedlist
 {
    private:
            typedef struct student
             {  // declaration student struct with 4 variable & 1 pointer
                char id[10];                    // store student id
                char name[15];                  // store student name
                char family[20];                // store student family
                bool gender;                    // true=male : false=female
                student *next;                  // store next node address(link)
             };                                 // end student struct
            typedef student *nodeptr;           // create new type: "nodeptr"
            nodeptr header, footer;             // create header & footer

    public:
	       slinkedlist();                       // constructor
	       int nodecounter;                     // node counter
           void add_student(bool first);        // declaration function of class
	       void add_first(char[],char[],char[],bool);
	       void add_last(char[],char[],char[],bool );
	       void remove_first();
	       void remove_by_id();
	       void remove_by_name();
	       void remove_by_family();
           void show_list();
           bool confirm(char[],char[],char[],bool,int);
 };                                             // end student linked list class
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** -----------------------------   main   ------------------------------ ***/
int main()
 {
    slinkedlist mydb;                           // create mydb as slinkedlist
    for( ; ; )                                  // unceasing loop !
     {
        switch (menu())                         // run menu function
         {
            case 1:
                 mydb.add_student(true);        // run add_student function
                 break;
            case 2:
                 mydb.add_student(false);       // run add_student function
                 break;
            case 3:
                 mydb.remove_first();           // run remove_first function
                 break;
            case 4:
                 mydb.remove_by_id();           // run remove_by_id function
                 break;
            case 5:
                 mydb.remove_by_name();         // run remove_by_name function
                 break;
            case 6:
                 mydb.remove_by_family();       // run remove_by_family function
                 break;
            case 7:
                 mydb.show_list();              // run show_list function
                 break;
            case 65:
            case 8:
                 system("cls");                 // clear screen
                 system("color 3e");            // change text color to aqua
                 cout<<"\n  Programming by"<<endl<<endl<<endl;
                 cout<<"\t\t\tJavad Evazzadeh";
                 getch();                       // show programmer data & pause
                 return 0;                      // return Exit_Success

            default:
                    system("color 0b");         // change text color to aqua
                    cout<<"\a\t\t incorrect!";  // beep and show message
                    system("color 07");         // switch to default color
         }                                      // end switch
     }                                          // end for
 }                                              // end main
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** ----------------------   show menu for user   ----------------------- ***/
int menu()
 {  // show menu for user to choose commands
    system("cls");                              // clear screen
    cout<<"This simple program managing information by linked list."<<endl;
    cout<<"in this program you can add, delete and show student data\n"<<endl;
    cout<<"1. Add student in front of list(stack)"<<endl;
    cout<<"2. Add student in rear of list(queue)\n---"<<endl;
    cout<<"3. Delete student"<<endl;
    cout<<"4. Delete student by student id"<<endl;
    cout<<"5. Delete student by student name"<<endl;
    cout<<"6. Delete student by student family\n---"<<endl;
    cout<<"7. show students\n---"<<endl;
    cout<<"8. Exit"<<endl<<endl;
    cout<<"\t\t]\ryour choice [ ";
    return (getche()-48);
 }  // in previous line: give user chioce and chage it from ascii to number
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** --------------------------   constructor   -------------------------- ***/
slinkedlist::slinkedlist()
 {
    header = NULL;                              // copy null in header
    footer = header;                            // copy header in footer
    nodecounter = 0;                            // reset nodecounter
 }
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** -------------------------   add to first   -------------------------- ***/
void slinkedlist::add_first
     (char myid[],char myname[],char myfamily[],bool mygender)
 {  // insert a new node at the header of the list
    if(confirm(myid,myname,myfamily,mygender,1))
    {
     nodeptr current;                            // create newpointer as student
     current = new student;
     // give student space and assign it to current
     strcpy(current->id,myid);                   // ......................... //
     strcpy(current->name,myname);               //  copy data entered by the //
     strcpy(current->family,myfamily);           //   user to current->data   //
     current->gender=mygender;                   // ````````````````````````` //

     current->next = header;                     // assign headerto curent->link
     header = current;                           // equate header with current
     if (nodecounter == 0) footer = current;     
     // if there was no node, equate footer with current
     nodecounter++;                              // counter++
    }
 }
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** --------------------------   add to last   -------------------------- ***/
void slinkedlist::add_last
     (char myid[],char myname[],char myfamily[],bool mygender)
 {  // insert a new node to the footer of the list
    if(confirm(myid,myname,myfamily,mygender,1)) 
    {
     nodeptr current;                            // create newpointer as student
     current = new student;
     // give student space and assign it to current
     strcpy(current->id,myid);                   // ......................... //
     strcpy(current->name,myname);               //  copy data entered by the //
     strcpy(current->family,myfamily);           //   user to current->data   //
     current->gender=mygender;                   // ````````````````````````` //

     current->next = NULL;                       // assign NULL to current->link
     if (nodecounter == 0) header = current;     
     // if there was no node, equate header with current 
     else footer->next = current;                // else footer->link = current
     footer = current;                           // equate footer with current
     nodecounter++;                              // counter++
    } 
 }
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** -----------------------   remove from first   ----------------------- ***/
void slinkedlist::remove_first()
 {  // remove first node from the list
    nodeptr current;                            // create new pointer as student
    current = header;                           // equate current with header
    if (nodecounter == 0)                       // if there was no node
     {                    
        system("color 0f");                     // change color to bright white
        cout <<endl<< "\a\t\t\tERROR: there is no item to remove!";
        getch();                                // show above message and pause
        system("color 07");                     // switch to default color
     }
    else                                        // else run below commands
     {
        if(confirm(current->id,current->name,current->family,current->gender,2))
         {
            header = current->next;             // assign current->next toheader
            delete current;                     // delete current(target)
            nodecounter--;                      // counter--
            if (nodecounter == 0) footer = header;
         }
     }  // in previous line: if there was no node, equate footer with header
}
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** ---------------------   special remove by id   ---------------------- ***/
void slinkedlist::remove_by_id()
 {  // remove special node by using id from the list
    char targetid[10];                          // for storing student id
    bool available = false;                     // for check available
    nodeptr current, target;                    // create new pointer as student
    current = header;                           // equate current with header

    if (nodecounter == 0)                       // if there was no node
     {
        system("color 0f");                     // change color to bright white
        cout <<endl<< "\a\t\t\tERROR: there is no item to remove!";
        getch();                                // show above message and pause
        system("color 07");                     // switch to default color
     }
    else                                        // else run below commands
     {
        cout<<endl<<"enter student id to delete from list: ";
        cin.getline(targetid,10);               // give id from user
        cin.clear();                            // clear the error bits
        cin.sync();                             // synchronize the input buffer

        if ((strcmp (header->id,targetid))==0)  // if first id equal target id
           remove_first();                      // delete first node in list
        else                                    // else run below commands
         {
          for( ; ;current=current->next)        // locate node before the target
           {
              if(current->next==NULL) break;    // if current->link==null, break
              if(strcmp(current->next->id,targetid)==0)
               {  // if user entered id equal current->link->id
                  available = true;             // change available status
                  break;                        // and break loop
               }
           }                                    // end loop and locate target-1
          if (available)                        // if user entered id available
           {// show confirmation and after confirm delete target node
            target = current->next;
            if(confirm(target->id,target->name,target->family,target->gender,2))
             {  // if user confirm run below commands
                current->next = target->next;   // correct link 
                delete target;                  // delete target
                nodecounter--;                  // counter--
                if (nodecounter == 0) footer = header;
             }
           }// if id available compiler run above command else run below!
          else
           {
               system("color 0f");              // change color to bright white
               cout <<endl<< "\a\t\t\tERROR: your input id is not exist!";
               getch();                         // show message and pause
               system("color 07");              // switch to default color
           }
         }                                      // end inside else
     }                                          // end outside else
 }                                              // end remove_by_id function
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** --------------------   special remove by name   --------------------- ***/
void slinkedlist::remove_by_name()
 {  // remove special node by using name from the list
    char targetname[10];                        // for storing student name
    bool available = false;                     // for check available
    nodeptr current, target;                    // create new pointer as student
    current = header;                           // equate current with header

    if (nodecounter == 0)                       // if there was no node
     {
        system("color 0f");                     // change color to bright white
        cout <<endl<< "\a\t\t\tERROR: there is no item to remove!";
        getch();                                // show above message and pause
        system("color 07");                     // switch to default color
     }
    else                                        // else run below commands
     {
        cout<<endl<<"enter student name to delete from list: ";
        cin.getline(targetname,10);             // give name from user
        cin.clear();                            // clear the error bits
        cin.sync();                             // synchronize the input buffer

        if((strcmp(header->name,targetname))==0)// if firstname equal targetname
           remove_first();                      // delete first node in list
        else                                    // else run below commands
         {
          for( ; ;current=current->next)        // locate node before the target
           {
              if(current->next==NULL) break;    // if current->link==null, break
              if(strcmp(current->next->name,targetname)==0)
               {  // if user entered name equal current->link->name
                  available = true;             // change available status
                  break;                        // and break loop
               }
           }                                    // end loop and locate target-1
          if (available)                        // if entered name available
           {// show confirmation and after confirm delete target node
            target = current->next;
            if
            (confirm(target->id,target->name,target->family,target->gender,2))
             {  // if user confirm run below commands
                current->next = target->next;   // correct link 
                delete target;                  // delete target
                nodecounter--;                  // counter--
                if (nodecounter == 0) footer = header;
             }
           }// if name available compiler run above command else run below!
          else
           {
               system("color 0f");              // change color to bright white
               cout <<endl<< "\a\t\t\tERROR: your input name is not exist!";
               getch();                         // show message and pause
               system("color 07");              // switch to default color
           }
         }                                      // end inside else
     }                                          // end outside else
 }                                              // end remove_by_name function
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** --------------------   special remove by family   --------------------- ***/
void slinkedlist::remove_by_family()
 {  // remove special node by using family from the list
    char targetfamily[10];                      // for storing student family
    bool available = false;                     // for check available
    nodeptr current, target;                    // create new pointer as student
    current = header;                           // equate current with header

    if (nodecounter == 0)                       // if there was no node
     {
        system("color 0f");                     // change color to bright white
        cout <<endl<< "\a\t\t\tERROR: there is no item to remove!";
        getch();                                // show above message and pause
        system("color 07");                     // switch to default color
     }
    else                                        // else run below commands
     {
        cout<<endl<<"enter student family to delete from list: ";
        cin.getline(targetfamily,10);           // give family from user
        cin.clear();                            // clear the error bits
        cin.sync();                             // synchronize the input buffer

        if                                      // if family equal targetfamily
        ((strcmp(header->family,targetfamily))==0)
           remove_first();                      // delete first node in list
        else                                    // else run below commands
         {
          for( ; ;current=current->next)        // locate node before the target
           {
              if(current->next==NULL) break;    // if current->link==null, break
              if(strcmp(current->next->family,targetfamily)==0)
               {  // if user entered family equal current->link->family
                  available = true;             // change available status
                  break;                        // and break loop
               }
           }                                    // end loop and locate target-1
          if (available)                        // if entered family available
           {// show confirmation and after confirm delete target node
            target = current->next;
            if
            (confirm(target->id,target->name,target->family,target->gender,2))
             {  // if user confirm run below commands
                current->next = target->next;   // correct link 
                delete target;                  // delete target
                nodecounter--;                  // counter--
                if (nodecounter == 0) footer = header;
             }
           }// if family available compiler run above command else run below!
          else
           {
               system("color 0f");              // change color to bright white
               cout <<endl<< "\a\t\t\tERROR: your input family is not exist!";
               getch();                         // show message and pause
               system("color 07");              // switch to default color
           }
         }                                      // end inside else
     }                                          // end outside else
 }                                              // end remove_by_family function
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** -------------------------   show the list   ------------------------- ***/
void slinkedlist::show_list()
 {  // show all data of the list
    nodeptr current;                            // create new pointer as student
    current = header;                           // equate current with header

    system("cls");                              // clear screen & show messages
    system("color 0e");                         // change text color to yellow
    cout<<"now in this list you can see all information of ";
    cout<<nodecounter<<" student!"<<endl<<endl;
    cout<<"Record\tStudentID\tName\t\tFamily\t\t\tGender"<<endl;
    cout<<"------\t---------\t----\t\t------\t\t\t------"<<endl<<endl;

    for(int i=1; current!=NULL; current=current->next, i++)
     {  // in this loop we show the data of list, form first to last
        cout<<" "<<right<<setfill('0')<<setw(4)<<i<<"\t";
        cout<<setfill(' ')<<left<<setw(9)<<current->id<<"\t";
        cout<<setw(10)<<current->name<<"\t"<<setw(20)<<current->family<<"\t";
        cout<<(current->gender ? "male" :"female")<<endl;
     }  // in previous line: if gender value is true, show male else show female

       cout<<endl<<endl<<endl;                  // new line
       cout<<"press any key to continue...";
       getch();                                 // show above message and pause
       system("color 07");                      // switch to default color
 }
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** -----------------------   confirmation   ------------------------- ***/
bool slinkedlist::confirm
     (char myid[],char myname[],char myfamily[],bool mygender, int permission)
 {  // confirmation data (0=only show, 1=add, 2=delete)
    cout<<endl<<endl<<"\t";                     // new line
    for(int i=0;i<63;i++) cout<<"-";            // show dash line
    cout<<endl;                                 // new line
    cout<<"\t StudentID\tName\t\tFamily\t\t\tGender"<<endl;
    cout<<"\t ---------\t----\t\t------\t\t\t------"<<endl;

    cout<<"\t "<<setfill(' ')<<left<<setw(9)<<myid<<"\t";
    cout<<setw(10)<<myname<<"\t"<<setw(20)<<myfamily<<"\t";
    cout<<(mygender ? "male" :"female")<<endl<<"\t";
    // in previous line: if gender value is true, show male else show female
    for(int i=0;i<63;i++) cout<<"-";            // show dash line
    cout<<endl<<endl;                           // new line
    switch(permission)
     {  // in this switch we show related message for user
        case 1:
             system("color 0a");                // change screen color to green
             cout<<"\tDo you want to add this record in list?"<<endl;
             break;
        case 2:
             system("color 0c");                // change screen color to red
             cout<<"\tDo you want to remove this record from list?"<<endl;
             break;
        default:
                getch();
                return false;
     }                                          // end switch
    cout<<"\tpress (y) to confirm or another key to refuse>";
    tmp = getch();                              // player press a one key
    system("color 07");                         // switch to default color
    if(tmp=='y') return true;                   // if user confirm return true
    else return false;                          // else return false
 }
/*** ````````````````````````````````````````````````````````````````````` ***/

/*** -------------   give data from user for adding to list   ------------ ***/
void slinkedlist::add_student(bool first)
 {  // give data from user one by one for adding to list by custom order
    char newid[10];                             // ......................... //   
    char newname[15];                           //        declaration        //
    char newfamily[20];                         //          variable         //
    bool newgender;                             // ````````````````````````` //

    system("cls");                              // clear screen
    cout<<"Enter student data to add in database!"<<endl<<endl;
    cout<<endl<<"ID: \t\t";
    cin.getline(newid,10);                      // give id from user
    cin.clear();             // clear the error bits for the cin input stream
    cin.sync();              // synchronize the input buffer,
                             // discarding any leftover characters in the buffer
    cout<<endl<<"Name: \t\t";
    cin.getline(newname,20);                    // give name from user
    cin.clear();
    cin.sync();

    cout<<endl<<"Family: \t";
    cin.getline(newfamily,40);                  // give family from user
    cin.clear();
    cin.sync();

    cout<<endl<<"\t]\t1.male\t2.female\rGender[";
    for (;;)                                    // unceasing loop !
     {  // in next line: give user chioce and chage it from ascii to number
        tmp = getch()-48;                      // 1=ture=male, 2=false=female
        if(tmp==-35);
        else
         {
            if (tmp==1) { newgender=true; cout<<tmp; break; }
            else if (tmp==2) { newgender=false; cout<<tmp; break; }
            else 
             {
                system("color 0b");            // change text color to aqua
                cout<<"]\a\t\t\t\toops!\tdont press "<<char(tmp+48)
                    <<" only 1 or 2\rGender["<<"\t]\t1.male\t2.female\rGender[";
                system("color 07");            // switch to default color
             }
         }
     }
     // if first==true add to first of list else add to last of list
     if (first) add_first(newid,newname,newfamily,newgender);
     else add_last(newid,newname,newfamily,newgender);
 }
 /*** ````````````````````````````````````````````````````````````````````` ***/

/*****************************************************************************/
/*   Programming by                                                          */
/*                  870382401     Javad Evazzadeh Kakroudi                   */
/*****************************************************************************/